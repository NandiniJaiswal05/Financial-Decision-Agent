# Buy or Wait? — Enterprise FinTech Affordability Agent

An AI-powered financial reasoning system built on a **Hybrid Neuro-Symbolic Architecture** designed for high-throughput affordability evaluation on Google Cloud Platform (GCP).

The system determines whether a user can safely afford a requested purchase or financial commitment by evaluating baseline cash flows, recurring commitments, pending payments, essential spending, and unstructured receipt images and text messages over a 90-day forecast window.

---

## Architectural Highlights

1. **Neuro-Symbolic Separation**:
   - **Symbolic Core (Deterministic Solver)**: Handles daily cash flow forecasting, 90-day balance trajectories ($B(t) \ge B_{\text{min}}$), foreign exchange normalization, and plan candidate ranking. Guaranteed mathematical accuracy with 0 hallucination risk.
   - **Neural Core (Vertex AI Gemini 2.5 Flash)**: Dedicated strictly to untrusted data perception (multimodal OCR on receipts and NLP message parsing for subscription updates or explicit cancellations).
2. **Prompt Injection & Security Shielding**:
   - System instructions isolate untrusted text and images within secure delimiters.
   - Pydantic schema enforcement (`response_schema`) forces structured JSON outputs and ignores embedded instruction overrides.
3. **6-Step Decision Ranking Matrix**:
   When multiple safe payment plans exist, candidates are evaluated by:
   - Priority 1: Complete full request by `desired_completion_date`.
   - Priority 2: Require zero spending changes (`spending_changes_needed = none`).
   - Priority 3: Minimize total payable amount.
   - Priority 4: Start payment as early as possible.
   - Priority 5: Use fewer payments.
   - Priority 6: Deterministic tie-breaker selecting lowest `payment_option_id`.

---

## Project Structure

```text
buy-or-wait-agent/
├── README.md                      # System documentation & execution guide
├── pyproject.toml                 # Dependency specifications
├── run_solution.py                # Master pipeline execution entrypoint
├── output.csv                     # Predictions for dataset/requests.csv
│
├── dataset/                       # Benchmark data files
│   ├── requests.csv
│   ├── sample_requests.csv
│   ├── financial_profiles.csv
│   ├── financial_events.csv
│   ├── exchange_rates.csv
│   ├── request_payment_options.csv
│   ├── messages.csv
│   ├── images.csv
│   └── media/images/              # Receipt artifacts (PNG)
│
├── evaluation/                    # Verification & auditing deliverables
│   ├── usage_report.md            # Generated token usage and cost report
│   └── validate_output.py         # Schema compliance & invariant auditor
│
└── src/                           # Application source code
    ├── ledger/
    │   ├── fx_converter.py        # O(1) hashed FX rate conversion
    │   └── state_builder.py       # Reconciles P1-P4 lifecycle events & state
    ├── engine/
    │   ├── cash_flow.py           # 90-day trajectory solver (B(t) >= B_min)
    │   └── plan_optimizer.py      # Flexible spending permutator & 6-step ranker
    ├── perception/
    │   └── client.py              # Vertex AI Gemini client with token tracking
    └── utils/
        ├── schema_validation.py   # OutputPrediction Pydantic invariants
        └── token_tracker.py       # Thread-safe token accountant

Environment Setup & Requirements
Prerequisites
Python >= 3.10

Google Cloud SDK (for Vertex AI perception features)

Installation
1. Clone or extract the repository:
