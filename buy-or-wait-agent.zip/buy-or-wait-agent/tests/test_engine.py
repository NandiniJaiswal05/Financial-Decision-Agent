import pytest
from datetime import datetime
from src.ledger.state_builder import UserFinancialProfile, NormalizedEvent
from src.engine.cash_flow import CashFlowSimulator

@pytest.fixture
def sample_profile():
    return UserFinancialProfile(
        user_id="u_01",
        home_currency="USD",
        available_balance=1000.0,
        minimum_balance_to_keep=200.0,
        financial_priorities=[],
        spending_preferences=[],
        payment_methods_user_will_consider=["full_payment", "installments"]
    )

@pytest.fixture
def sample_events():
    return [
        NormalizedEvent(
            event_id="e_01", user_id="u_01", event_date="2026-09-15",
            event_type="salary", amount=2000.0, currency="USD",
            is_flexible=False, is_recurring=True, recurrence_interval_days=30,
            is_settled=True, linked_event_id=None, description="Monthly Salary"
        ),
        NormalizedEvent(
            event_id="e_02", user_id="u_01", event_date="2026-09-20",
            event_type="recurring_expense", amount=500.0, currency="USD",
            is_flexible=False, is_recurring=True, recurrence_interval_days=30,
            is_settled=True, linked_event_id=None, description="Rent"
        )
    ]

def test_compute_capacity(sample_profile, sample_events):
    """Tests if the engine correctly identifies how much is safe to pay today."""
    simulator = CashFlowSimulator(sample_profile, sample_events)
    request_date = "2026-09-12"
    requested_amount = 1500.0
    
    amount_safe, earliest_date = simulator.compute_capacity(request_date, requested_amount)
    
    # Balance starts at 1000, Min is 200. Safe today before salary is 800.
    assert amount_safe == 800.0
    # Salary hits on 09-15 (+2000), making the full 1500 affordable then.
    assert earliest_date == "2026-09-15"

def test_verify_plan_safety(sample_profile, sample_events):
    """Tests if a proposed payment plan violates the minimum balance."""
    simulator = CashFlowSimulator(sample_profile, sample_events)
    request_date = "2026-09-12"
    
    # Test a safe installment plan (pays 300 immediately, well within the 800 safe margin)
    safe_plan = [("2026-09-12", 300.0), ("2026-10-12", 300.0)]
    assert simulator.verify_plan_safety(request_date, safe_plan, dropped_events=[]) == True

    # Test an unsafe plan (pays 900 immediately, leaving 100 which is < min 200)
    unsafe_plan = [("2026-09-12", 900.0)]
    assert simulator.verify_plan_safety(request_date, unsafe_plan, dropped_events=[]) == False