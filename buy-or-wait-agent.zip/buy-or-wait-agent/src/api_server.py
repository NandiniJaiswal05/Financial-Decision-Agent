# src/api_server.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os
import pandas as pd

app = FastAPI(
    title="Buy or Wait? FinTech Agent API",
    description="Enterprise Affordability Decision Engine powered by Vertex AI & Cash Flow Solver",
    version="1.0.0"
)

class AffordabilityRequest(BaseModel):
    user_id: str
    request_id: str
    request_date: str
    requested_amount: float
    desired_completion_date: str
    allows_partial_payment: bool = True

@app.get("/")
def health_check():
    return {"status": "healthy", "service": "buy-or-wait-engine", "version": "1.0.0"}

@app.post("/evaluate")
def evaluate_request(payload: AffordabilityRequest):
    # Hook into your core simulation and optimization engine here
    try:
        # For real-time inference, you can query your ledger and run the simulator
        return {
            "request_id": payload.request_id,
            "user_id": payload.user_id,
            "amount_safe_to_pay": min(payload.requested_amount, 500.0),
            "affordability_status": "affordable_now" if payload.requested_amount <= 500 else "affordable_with_plan",
            "recommended_payment_method": "full_payment" if payload.requested_amount <= 500 else "installments",
            "decision_explanation": "Evaluated successfully via real-time GCP Cloud Run endpoint."
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))