import pandas as pd
from typing import Dict, Tuple

class FXConverter:
    def __init__(self, exchange_rates_path: str):
        self.rates_cache: Dict[Tuple[str, str, str], float] = {}
        self._load_rates(exchange_rates_path)

    def _load_rates(self, filepath: str):
        try:
            df = pd.read_csv(filepath)
            df.columns = [str(c).strip() for c in df.columns]

            for _, row in df.iterrows():
                date_str = str(row['rate_date']).strip()
                base = str(row['from_currency']).strip().upper()
                target = str(row['to_currency']).strip().upper()
                rate = float(row['rate'])
                
                self.rates_cache[(date_str, base, target)] = rate
                if rate > 0 and base != target:
                    self.rates_cache[(date_str, target, base)] = 1.0 / rate
                    
        except Exception as e:
            raise RuntimeError(f"Failed to load exchange rates from {filepath}: {str(e)}")

    def convert(self, amount: float, date: str, from_curr: str, to_curr: str) -> float:
        from_curr = from_curr.upper()
        to_curr = to_curr.upper()
        
        if from_curr == to_curr or amount == 0:
            return amount
            
        rate = self.rates_cache.get((date, from_curr, to_curr))
        if rate is None:
            matching = [r for (d, f, t), r in self.rates_cache.items() if f == from_curr and t == to_curr]
            if matching:
                rate = matching[0]
            else:
                raise ValueError(f"Missing exchange rate for {from_curr}->{to_curr} on {date}")
            
        return round(amount * rate, 2)