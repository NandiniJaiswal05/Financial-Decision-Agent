import pandas as pd
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from src.ledger.fx_converter import FXConverter


@dataclass
class UserFinancialProfile:
    user_id: str
    home_currency: str
    available_balance: float
    minimum_balance_to_keep: float
    financial_priorities: List[str]
    expense_categories_to_protect: List[str]
    expense_categories_user_is_willing_to_reduce: List[str]
    expense_categories_user_is_willing_to_stop: List[str]
    payment_methods_user_will_consider: List[str]
    max_installment_months: int

@dataclass
class NormalizedEvent:
    event_id: str
    user_id: str
    event_date: str
    event_type: str
    category: str
    direction: str
    amount: float
    currency: str
    settlement_date: str
    status: str
    is_flexible: bool
    is_recurring: bool
    recurrence_interval_days: int
    is_settled: bool
    linked_event_id: Optional[str]
    description: str
    minimum_allowed_amount: float
    state_status: str = "active"


class LedgerStateBuilder:
    def __init__(self, profiles_path: str, events_path: str, fx_converter: FXConverter):
        self.fx_converter = fx_converter
        self.profiles: Dict[str, UserFinancialProfile] = {}
        self.events_by_user: Dict[str, List[NormalizedEvent]] = {}
        
        self._load_profiles(profiles_path)
        self._load_and_reconcile_events(events_path)

    def _clean_df(self, df: pd.DataFrame) -> pd.DataFrame:
        df.columns = [str(c).strip() for c in df.columns]
        return df

    def _load_profiles(self, filepath: str):
        df = self._clean_df(pd.read_csv(filepath))
        for _, row in df.iterrows():
            user_id = str(row['user_id']).strip()
            parse_list = lambda val: [x.strip() for x in str(val).split('|') if x.strip()] if pd.notna(val) else []

            profile = UserFinancialProfile(
                user_id=user_id,
                home_currency=str(row['home_currency']).strip().upper(),
                available_balance=float(row['current_available_balance']),
                minimum_balance_to_keep=float(row['minimum_balance_to_keep']),
                financial_priorities=parse_list(row.get('financial_priorities', '')),
                expense_categories_to_protect=parse_list(row.get('expense_categories_to_protect', '')),
                expense_categories_user_is_willing_to_reduce=parse_list(row.get('expense_categories_user_is_willing_to_reduce', '')),
                expense_categories_user_is_willing_to_stop=parse_list(row.get('expense_categories_user_is_willing_to_stop', '')),
                payment_methods_user_will_consider=parse_list(row.get('payment_methods_user_will_consider', '')),
                max_installment_months=int(row.get('max_installment_months', 12)) if pd.notna(row.get('max_installment_months')) else 12
            )
            self.profiles[user_id] = profile
            self.events_by_user[user_id] = []

    def _load_and_reconcile_events(self, filepath: str):
        df = self._clean_df(pd.read_csv(filepath))
        raw_events_by_id: Dict[str, dict] = {}
        linked_chain: Dict[str, List[str]] = {}

        for _, row in df.iterrows():
            event_id = str(row['event_id']).strip()
            user_id = str(row['user_id']).strip()
            linked_raw = row.get('linked_event_id')
            linked_id = str(linked_raw).strip() if pd.notna(linked_raw) and str(linked_raw).strip() not in ('', 'nan', 'none') else None

            flex_val = str(row.get('flexibility', '')).strip().lower()
            is_flexible = flex_val in ('flexible', 'optional', 'true', 'yes', 'reduceable', 'stoppable')
            
            evt_type = str(row.get('event_type', '')).strip().lower()
            is_recurring = any(k in evt_type for k in ['recurring', 'salary', 'subscription', 'rent', 'installment'])
            
            status_val = str(row.get('status', 'settled')).strip().lower()
            is_settled = status_val in ('settled', 'completed', 'confirmed', 'paid')

            raw_events_by_id[event_id] = {
                'event_id': event_id,
                'user_id': user_id,
                'event_date': str(row['event_date']).strip(),
                'event_type': evt_type,
                'category': str(row.get('category', '')).strip().lower(),
                'direction': str(row.get('direction', '')).strip().lower(),
                'amount': float(row['amount']) if pd.notna(row.get('amount')) else None,
                'currency': str(row['currency']).strip().upper() if pd.notna(row.get('currency')) else None,
                'settlement_date': str(row.get('settlement_date', '')).strip(),
                'status': status_val,
                'is_flexible': is_flexible,
                'is_recurring': is_recurring,
                'recurrence_interval_days': 30 if is_recurring else 0,
                'is_settled': is_settled,
                'linked_event_id': linked_id,
                'description': str(row.get('description', '')).strip(),
                'minimum_allowed_amount': float(row.get('minimum_allowed_amount', 0.0)) if pd.notna(row.get('minimum_allowed_amount')) else 0.0,
                'raw_row': row
            }

            if linked_id:
                if linked_id not in linked_chain:
                    linked_chain[linked_id] = []
                linked_chain[linked_id].append(event_id)

        cancelled_events: Set[str] = set()
        overridden_events: Set[str] = set()

        for parent_id, children_ids in linked_chain.items():
            parent = raw_events_by_id.get(parent_id)
            if not parent:
                continue

            for child_id in children_ids:
                child = raw_events_by_id.get(child_id)
                if not child:
                    continue

                child_type = child['event_type']
                if 'cancel' in child_type or 'refund' in child_type or 'cancel' in child['description'].lower() or child['status'] in ('cancelled', 'failed'):
                    cancelled_events.add(parent_id)
                    cancelled_events.add(child_id)
                    continue

                if child['is_settled'] and not parent['is_settled']:
                    overridden_events.add(parent_id)
                elif child['event_date'] >= parent['event_date']:
                    overridden_events.add(parent_id)
                else:
                    is_income = child['direction'] in ('inflow', 'income', 'credit') or 'salary' in parent['event_type']
                    p_amt = parent['amount'] or 0.0
                    c_amt = child['amount'] or 0.0
                    
                    if is_income:
                        if p_amt <= c_amt:
                            overridden_events.add(child_id)
                        else:
                            overridden_events.add(parent_id)
                    else:
                        if p_amt >= c_amt:
                            overridden_events.add(child_id)
                        else:
                            overridden_events.add(parent_id)

        for event_id, raw in raw_events_by_id.items():
            if event_id in cancelled_events or event_id in overridden_events:
                continue

            user_id = raw['user_id']
            profile = self.profiles.get(user_id)
            if not profile:
                continue

            raw_currency = raw['currency'] or profile.home_currency
            raw_amount = raw['amount'] if raw['amount'] is not None else 0.0

            normalized_amount = self.fx_converter.convert(
                amount=raw_amount,
                date=raw['event_date'],
                from_curr=raw_currency,
                to_curr=profile.home_currency
            )

            cat = raw['category']
            is_flex = raw['is_flexible'] or (cat in profile.expense_categories_user_is_willing_to_reduce) or (cat in profile.expense_categories_user_is_willing_to_stop)

            norm_event = NormalizedEvent(
                event_id=event_id,
                user_id=user_id,
                event_date=raw['event_date'],
                event_type=raw['event_type'],
                category=cat,
                direction=raw['direction'],
                amount=normalized_amount,
                currency=profile.home_currency,
                settlement_date=raw['settlement_date'],
                status=raw['status'],
                is_flexible=is_flex,
                is_recurring=raw['is_recurring'],
                recurrence_interval_days=raw['recurrence_interval_days'],
                is_settled=raw['is_settled'],
                linked_event_id=raw['linked_event_id'],
                description=raw['description'],
                minimum_allowed_amount=raw['minimum_allowed_amount']
            )

            self.events_by_user[user_id].append(norm_event)

    def apply_perception_overrides(self, perception_events: List[dict]):
        for p_evt in perception_events:
            user_id = p_evt.get('user_id')
            target_event_id = p_evt.get('event_id')
            action = p_evt.get('action')

            if not user_id or user_id not in self.events_by_user:
                continue

            user_events = self.events_by_user[user_id]

            if action == 'cancel' and target_event_id:
                self.events_by_user[user_id] = [e for e in user_events if e.event_id != target_event_id]

            elif action == 'amend' and target_event_id:
                for e in user_events:
                    if e.event_id == target_event_id:
                        if p_evt.get('amount') is not None:
                            profile = self.profiles[user_id]
                            e.amount = self.fx_converter.convert(
                                amount=float(p_evt['amount']),
                                date=e.event_date,
                                from_curr=p_evt.get('currency', profile.home_currency),
                                to_curr=profile.home_currency
                            )
                        if p_evt.get('is_flexible') is not None:
                            e.is_flexible = bool(p_evt['is_flexible'])

    def get_user_profile(self, user_id: str) -> UserFinancialProfile:
        if user_id not in self.profiles:
            raise KeyError(f"User profile for '{user_id}' not found.")
        return self.profiles[user_id]

    def get_active_events(self, user_id: str) -> List[NormalizedEvent]:
        return self.events_by_user.get(user_id, [])