import re
from typing import Optional
from pydantic import BaseModel, Field, model_validator

class OutputPrediction(BaseModel):
    request_id: str
    amount_safe_to_pay: float = Field(ge=0.0)
    affordability_status: str
    recommended_payment_method: str
    payment_plan: str
    earliest_date_for_full_payment: Optional[str]
    spending_changes_needed: str
    decision_explanation: str

    # Requested amount passed as context to validate invariants, not part of final CSV output
    _requested_amount: float = 0.0 

    def set_requested_amount(self, amount: float):
        self._requested_amount = amount
        return self

    @model_validator(mode='after')
    def enforce_invariants(self) -> 'OutputPrediction':
        # 1. Safe amount cannot exceed requested amount
        if self._requested_amount > 0 and self.amount_safe_to_pay > self._requested_amount:
            raise ValueError(f"amount_safe_to_pay ({self.amount_safe_to_pay}) exceeds requested ({self._requested_amount})")

        # 2. affordable_now constraint
        if self.affordability_status == "affordable_now":
            if not self.earliest_date_for_full_payment:
                raise ValueError("affordable_now requires earliest_date_for_full_payment to be set (must equal request_date).")

        # 3. Payment plan format validation (YYYY-MM-DD:Amount|... or 'none')
        if self.payment_plan != "none":
            plan_pattern = re.compile(r"^(\d{4}-\d{2}-\d{2}:\d+(\.\d+)?)(\|\d{4}-\d{2}-\d{2}:\d+(\.\d+)?)*$")
            if not plan_pattern.match(self.payment_plan):
                raise ValueError(f"Invalid payment_plan format: {self.payment_plan}")

        # 4. Spending changes format validation (stop:id|reduce_to:id:amount or 'none')
        if self.spending_changes_needed != "none":
            changes = self.spending_changes_needed.split("|")
            if len(changes) > 3:
                raise ValueError("Maximum 3 spending changes allowed.")
            
            seen_events = set()
            for change in changes:
                parts = change.split(":")
                if parts[0] not in ("stop", "reduce_to"):
                    raise ValueError(f"Invalid spending change action: {parts[0]}")
                
                event_id = parts[1]
                if event_id in seen_events:
                    raise ValueError(f"Mutually exclusive / duplicate rule for event: {event_id}")
                seen_events.add(event_id)

        return self

    def to_csv_dict(self) -> dict:
        """Returns the dictionary mapped exactly to the required output.csv columns."""
        return {
            "request_id": self.request_id,
            "amount_safe_to_pay": round(self.amount_safe_to_pay, 2),
            "affordability_status": self.affordability_status,
            "recommended_payment_method": self.recommended_payment_method,
            "payment_plan": self.payment_plan,
            "earliest_date_for_full_payment": self.earliest_date_for_full_payment or "",
            "spending_changes_needed": self.spending_changes_needed,
            "decision_explanation": self.decision_explanation
        }