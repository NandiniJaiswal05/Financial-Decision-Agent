import os
import threading
from typing import Dict

class TokenTracker:
    _instance = None
    _lock = threading.Lock()
    
    # Official GCP Gemini Pricing per 1k tokens (Standard Tier)
    PRICING = {
        "gemini-2.5-flash": {"input": 0.000075, "output": 0.00030},
        "gemini-1.5-flash": {"input": 0.000075, "output": 0.00030},
    }

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(TokenTracker, cls).__new__(cls)
                cls._instance._init_tracker()
            return cls._instance

    def _init_tracker(self):
        self.total_calls = 0
        self.input_tokens = 0
        self.output_tokens = 0
        self.model_usage: Dict[str, Dict[str, int]] = {}
        self.api_failures = 0

    def log_call(self, model_name: str, input_tokens: int, output_tokens: int):
        with self._lock:
            self.total_calls += 1
            self.input_tokens += input_tokens
            self.output_tokens += output_tokens

            if model_name not in self.model_usage:
                self.model_usage[model_name] = {"calls": 0, "input": 0, "output": 0}

            self.model_usage[model_name]["calls"] += 1
            self.model_usage[model_name]["input"] += input_tokens
            self.model_usage[model_name]["output"] += output_tokens

    def log_failure(self):
        with self._lock:
            self.api_failures += 1

    def generate_report(self, total_requests: int, output_filepath: str = "evaluation/usage_report.md"):
        os.makedirs(os.path.dirname(output_filepath), exist_ok=True)
        total_cost = 0.0
        
        lines = [
            "# Token Usage and Cost Analysis Report\n",
            "## Summary of Execution Run",
            f"- **Total Benchmark Requests Evaluated:** {total_requests}",
            f"- **Total LLM/VLM API Calls:** {self.total_calls}",
            f"- **Failed API Calls (Safeguards/Timeouts):** {self.api_failures}",
            f"- **Total Input Tokens:** {self.input_tokens:,}",
            f"- **Total Output Tokens:** {self.output_tokens:,}",
            f"- **Average Tokens Per Request:** {((self.input_tokens + self.output_tokens) / max(1, total_requests)):.2f}\n",
            "## Model Breakdown\n",
            "| Model Name | Calls | Input Tokens | Output Tokens | Est. Input Cost ($) | Est. Output Cost ($) | Total Cost ($) |",
            "| :--- | :--- | :--- | :--- | :--- | :--- | :--- |"
        ]

        for model, usage in self.model_usage.items():
            rates = self.PRICING.get(model, {"input": 0.000075, "output": 0.00030})
            in_cost = (usage["input"] / 1000.0) * rates["input"]
            out_cost = (usage["output"] / 1000.0) * rates["output"]
            m_cost = in_cost + out_cost
            total_cost += m_cost
            
            lines.append(
                f"| `{model}` | {usage['calls']} | {usage['input']:,} | {usage['output']:,} | ${in_cost:.4f} | ${out_cost:.4f} | **${m_cost:.4f}** |"
            )

        avg_cost_per_req = total_cost / max(1, total_requests)
        lines.extend([
            "\n## Financial Summary",
            f"- **Estimated Total Run Cost:** `${total_cost:.4f}`",
            f"- **Estimated Cost Per Request:** `${avg_cost_per_req:.6f}`"
        ])

        with open(output_filepath, "w") as f:
            f.write("\n".join(lines))