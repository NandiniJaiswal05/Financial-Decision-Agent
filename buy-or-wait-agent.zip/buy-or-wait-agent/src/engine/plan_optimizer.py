from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Tuple, Dict, Set
from itertools import combinations
from src.ledger.state_builder import UserFinancialProfile, NormalizedEvent
from src.engine.cash_flow import CashFlowSimulator


@dataclass
class PaymentOption:
    payment_option_id: str
    request_id: str
    option_type: str
    start_date: str
    num_payments: int
    days_between_payments: int
    explicit_financing_fee: float
    total_payable_amount: float
    payment_schedule: List[Tuple[str, float]]


@dataclass
class CandidatePlan:
    affordability_status: str
    recommended_payment_method: str
    payment_plan_str: str
    spending_changes_str: str
    first_payment_date: str
    last_payment_date: str
    total_paid: float
    num_payments: int
    completes_by_deadline: bool
    requires_no_spending_changes: bool
    payment_option_id: str
    spending_changes_count: int

    def sort_key(self) -> Tuple:
        return (
            not self.completes_by_deadline,
            not self.requires_no_spending_changes,
            round(self.total_paid, 2),
            self.first_payment_date,
            self.num_payments,
            self.payment_option_id
        )


class PlanOptimizer:
    def __init__(
        self,
        profile: UserFinancialProfile,
        events: List[NormalizedEvent],
        simulator: CashFlowSimulator,
        payment_options: List[PaymentOption]
    ):
        self.profile = profile
        self.events = events
        self.simulator = simulator
        self.payment_options = payment_options
        self.considered_methods = set(profile.payment_methods_user_will_consider)

    def _get_flexible_recurring_events(self) -> List[NormalizedEvent]:
        return [
            e for e in self.events 
            if e.is_flexible and e.is_recurring and e.amount > 0 and e.event_type.lower() not in ('salary', 'income')
        ]

    def _generate_spending_change_permutations(self) -> List[Tuple[List[str], str]]:
        flex_events = self._get_flexible_recurring_events()
        permutations: List[Tuple[List[str], str]] = [([], "none")]

        if not flex_events:
            return permutations

        single_cuts = []
        for e in flex_events:
            single_cuts.append(([e.event_id], f"stop:{e.event_id}"))
            reduced_amt = round(e.amount * 0.5, 2)
            single_cuts.append(([], f"reduce_to:{e.event_id}:{reduced_amt}"))

        permutations.extend(single_cuts)

        for k in (2, 3):
            if len(flex_events) >= k:
                for comb in combinations(flex_events, k):
                    dropped_ids = [e.event_id for e in comb]
                    changes_str = "|".join([f"stop:{e.event_id}" for e in comb])
                    permutations.append((dropped_ids, changes_str))

        return permutations

    def find_best_plan(
        self,
        request_date_str: str,
        requested_amount: float,
        desired_completion_date_str: str,
        allows_partial_payment: bool,
        amount_safe_to_pay: float,
        earliest_date_for_full_payment: Optional[str]
    ) -> CandidatePlan:
        candidates: List[CandidatePlan] = []
        spending_perms = self._generate_spending_change_permutations()

        # 1. Full Payment Today
        if "full_payment" in self.considered_methods:
            schedule = [(request_date_str, requested_amount)]
            plan_str = f"{request_date_str}:{requested_amount:.2f}".rstrip('0').rstrip('.')
            
            for dropped_ids, changes_str in spending_perms:
                if self.simulator.verify_plan_safety(request_date_str, schedule, dropped_ids):
                    is_now = (changes_str == "none" and amount_safe_to_pay >= requested_amount)
                    status = "affordable_now" if is_now else "affordable_with_plan"
                    
                    candidates.append(CandidatePlan(
                        affordability_status=status,
                        recommended_payment_method="full_payment",
                        payment_plan_str=plan_str,
                        spending_changes_str=changes_str,
                        first_payment_date=request_date_str,
                        last_payment_date=request_date_str,
                        total_paid=requested_amount,
                        num_payments=1,
                        completes_by_deadline=request_date_str <= desired_completion_date_str,
                        requires_no_spending_changes=(changes_str == "none"),
                        payment_option_id="zzzzzz",
                        spending_changes_count=len(dropped_ids)
                    ))
                    if is_now:
                        break

        # 2. Partial Payment
        if (
            allows_partial_payment and 
            "partial_payment" in self.considered_methods and 
            0 < amount_safe_to_pay < requested_amount and 
            earliest_date_for_full_payment and 
            earliest_date_for_full_payment <= desired_completion_date_str
        ):
            rem_amount = requested_amount - amount_safe_to_pay
            schedule = [
                (request_date_str, amount_safe_to_pay),
                (earliest_date_for_full_payment, rem_amount)
            ]
            plan_str = f"{request_date_str}:{amount_safe_to_pay:.2f}|{earliest_date_for_full_payment}:{rem_amount:.2f}"

            for dropped_ids, changes_str in spending_perms:
                if self.simulator.verify_plan_safety(request_date_str, schedule, dropped_ids):
                    candidates.append(CandidatePlan(
                        affordability_status="affordable_with_plan",
                        recommended_payment_method="partial_payment",
                        payment_plan_str=plan_str,
                        spending_changes_str=changes_str,
                        first_payment_date=request_date_str,
                        last_payment_date=earliest_date_for_full_payment,
                        total_paid=requested_amount,
                        num_payments=2,
                        completes_by_deadline=earliest_date_for_full_payment <= desired_completion_date_str,
                        requires_no_spending_changes=(changes_str == "none"),
                        payment_option_id="zzzzzz",
                        spending_changes_count=len(dropped_ids)
                    ))
                    break

        # 3. Installments Options
        if "installments" in self.considered_methods and self.payment_options:
            for opt in self.payment_options:
                schedule = opt.payment_schedule
                if not schedule:
                    continue
                
                plan_str = "|".join([f"{d}:{amt:.2f}" for d, amt in schedule])
                first_date = schedule[0][0]
                last_date = schedule[-1][0]

                for dropped_ids, changes_str in spending_perms:
                    if self.simulator.verify_plan_safety(request_date_str, schedule, dropped_ids):
                        candidates.append(CandidatePlan(
                            affordability_status="affordable_with_plan",
                            recommended_payment_method="installments",
                            payment_plan_str=plan_str,
                            spending_changes_str=changes_str,
                            first_payment_date=first_date,
                            last_payment_date=last_date,
                            total_paid=opt.total_payable_amount,
                            num_payments=len(schedule),
                            completes_by_deadline=last_date <= desired_completion_date_str,
                            requires_no_spending_changes=(changes_str == "none"),
                            payment_option_id=str(opt.payment_option_id),
                            spending_changes_count=len(dropped_ids)
                        ))
                        break

        # 4. Wait Strategy (Affordable Later)
        if "full_payment" in self.considered_methods and earliest_date_for_full_payment and earliest_date_for_full_payment > request_date_str:
            plan_str = f"{earliest_date_for_full_payment}:{requested_amount:.2f}"
            schedule = [(earliest_date_for_full_payment, requested_amount)]
            
            for dropped_ids, changes_str in spending_perms:
                if self.simulator.verify_plan_safety(request_date_str, schedule, dropped_ids):
                    candidates.append(CandidatePlan(
                        affordability_status="affordable_later",
                        recommended_payment_method="wait",
                        payment_plan_str="none",
                        spending_changes_str=changes_str,
                        first_payment_date=earliest_date_for_full_payment,
                        last_payment_date=earliest_date_for_full_payment,
                        total_paid=requested_amount,
                        num_payments=1,
                        completes_by_deadline=earliest_date_for_full_payment <= desired_completion_date_str,
                        requires_no_spending_changes=(changes_str == "none"),
                        payment_option_id="zzzzzz",
                        spending_changes_count=len(dropped_ids)
                    ))
                    break

        if candidates:
            candidates.sort(key=lambda c: c.sort_key())
            return candidates[0]

        return CandidatePlan(
            affordability_status="not_affordable",
            recommended_payment_method="not_recommended",
            payment_plan_str="none",
            spending_changes_str="none",
            first_payment_date=request_date_str,
            last_payment_date=request_date_str,
            total_paid=0.0,
            num_payments=0,
            completes_by_deadline=False,
            requires_no_spending_changes=True,
            payment_option_id="zzzzzz",
            spending_changes_count=0
        )