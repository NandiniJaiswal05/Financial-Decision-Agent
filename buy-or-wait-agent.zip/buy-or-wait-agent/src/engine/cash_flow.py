from datetime import datetime, timedelta
from typing import List, Tuple, Optional
from src.ledger.state_builder import UserFinancialProfile, NormalizedEvent

class CashFlowSimulator:
    def __init__(self, profile: UserFinancialProfile, events: List[NormalizedEvent]):
        self.profile = profile
        self.events = events
        self.min_balance = profile.minimum_balance_to_keep
        self.initial_balance = profile.available_balance

    def _parse_date(self, date_str: str) -> datetime.date:
        return datetime.strptime(date_str, "%Y-%m-%d").date()

    def _is_income(self, event: NormalizedEvent) -> bool:
        """Determines if the event adds to the balance."""
        direction = getattr(event, 'direction', '').lower()
        evt_type = getattr(event, 'event_type', '').lower()
        return direction in ('inflow', 'income', 'credit') or evt_type in ('salary', 'income', 'refund', 'inward_transfer')

    def _build_daily_deltas(self, request_date: datetime.date, days: int = 90) -> List[float]:
        """
        Projects all future income and expenses into a daily delta array for the next 90 days.
        Index 0 represents request_date.
        """
        deltas = [0.0] * (days + 1)
        end_date = request_date + timedelta(days=days)

        for event in self.events:
            event_date = self._parse_date(event.event_date)
            amount = event.amount if self._is_income(event.event_type) else -event.amount

            if event.is_recurring and event.recurrence_interval_days > 0:
                # Project recurring events forward
                current_date = event_date
                while current_date <= end_date:
                    if current_date >= request_date:
                        day_index = (current_date - request_date).days
                        deltas[day_index] += amount
                    current_date += timedelta(days=event.recurrence_interval_days)
            else:
                # One-time event
                if request_date <= event_date <= end_date:
                    day_index = (event_date - request_date).days
                    deltas[day_index] += amount

        return deltas

    def _build_balance_trajectory(self, deltas: List[float]) -> List[float]:
        """Converts daily deltas into cumulative daily balances B(t)."""
        trajectory = []
        current_b = self.initial_balance
        for delta in deltas:
            current_b += delta
            trajectory.append(current_b)
        return trajectory

    def compute_capacity(self, request_date_str: str, requested_amount: float) -> Tuple[float, Optional[str]]:
        """
        Computes `amount_safe_to_pay` and `earliest_date_for_full_payment`
        strictly based on baseline capacity (before considering user payment preferences).
        """
        request_date = self._parse_date(request_date_str)
        deltas = self._build_daily_deltas(request_date, days=90)
        trajectory = self._build_balance_trajectory(deltas)

        # 1. Calculate amount_safe_to_pay on day 0
        # How much can we subtract on day 0 without dropping B(t) < B_min on any future day?
        margins = [b - self.min_balance for b in trajectory]
        min_future_margin = min(margins)
        
        # We cannot pay more than the requested amount, nor more than our tightest future margin
        amount_safe_to_pay = max(0.0, min(requested_amount, min_future_margin))

        # 2. Calculate earliest_date_for_full_payment
        # Find the earliest day 'd' where subtracting requested_amount doesn't violate min_balance
        # from day 'd' through day 90.
        earliest_date_for_full = None
        for d in range(91):  # 0 to 90
            # The margin from day d to 90 must all be >= requested_amount
            min_margin_from_d = min(margins[d:])
            if min_margin_from_d >= requested_amount:
                safe_date = request_date + timedelta(days=d)
                earliest_date_for_full = safe_date.strftime("%Y-%m-%d")
                break

        return round(amount_safe_to_pay, 2), earliest_date_for_full

    def verify_plan_safety(self, request_date_str: str, plan_payments: List[Tuple[str, float]], dropped_events: List[str]) -> bool:
        """
        Simulates the baseline with a candidate payment plan and flexible spending cuts.
        Returns True if the plan never breaches the minimum balance.
        """
        request_date = self._parse_date(request_date_str)
        
        # Filter out dropped events for this permutation
        original_events = self.events
        self.events = [e for e in self.events if e.event_id not in dropped_events]
        
        deltas = self._build_daily_deltas(request_date, days=90)
        
        # Restore events
        self.events = original_events

        # Apply candidate plan payments to deltas
        for pay_date_str, amount in plan_payments:
            pay_date = self._parse_date(pay_date_str)
            if pay_date >= request_date:
                day_index = (pay_date - request_date).days
                if day_index <= 90:
                    deltas[day_index] -= amount

        trajectory = self._build_balance_trajectory(deltas)
        min_balance_in_trajectory = min(trajectory)
        
        return min_balance_in_trajectory >= self.min_balance