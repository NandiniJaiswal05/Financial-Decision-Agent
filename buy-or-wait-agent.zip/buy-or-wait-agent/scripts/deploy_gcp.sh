#!/bin/bash
# scripts/deploy_gcp.sh
set -e

PROJECT_ID=$(gcloud config get-value project)
REGION="us-central1"
REPO_NAME="fintech-agent-repo"
IMAGE_NAME="buy-or-wait-engine"
SERVICE_NAME="buy-or-wait-api"

IMAGE_URI="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO_NAME}/${IMAGE_NAME}:latest"

echo "Deploying ${IMAGE_URI} to Google Cloud Run..."

gcloud run deploy ${SERVICE_NAME} \
  --image ${IMAGE_URI} \
  --region ${REGION} \
  --platform managed \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --min-instances 1 \
  --max-instances 1000 \
  --set-env-vars=GOOGLE_CLOUD_PROJECT=${PROJECT_ID},GOOGLE_CLOUD_LOCATION=${REGION}

echo "Deployment complete! Service is live and ready to accept traffic."