#!/bin/bash
# scripts/generate_submission.sh
set -e # Exit immediately if a command exits with a non-zero status

echo "================================================="
echo " 1. RUNNING MASTER EVALUATION PIPELINE"
echo "================================================="
python3 run_solution.py

echo "================================================="
echo " 2. VALIDATING OUTPUT SCHEMA & INVARIANTS"
echo "================================================="
python3 evaluation/validate_output.py output.csv dataset/requests.csv

echo "================================================="
echo " 3. PACKAGING SUBMISSION (code.zip)"
echo "================================================="
# Remove old zip if it exists
rm -f code.zip

# Zip the required deliverables, excluding python caches and virtual envs
zip -r code.zip \
    README.md \
    pyproject.toml \
    run_solution.py \
    output.csv \
    evaluation/ \
    src/ \
    -x "*/__pycache__/*" "*/.pytest_cache/*" "*.DS_Store"

echo "================================================="
echo " SUCCESS: code.zip is ready for submission!"
echo " Includes: output.csv, usage_report.md, and source."
echo "================================================="