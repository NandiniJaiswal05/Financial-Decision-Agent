#!/bin/bash
# scripts/build_container.sh
set -e

PROJECT_ID=$(gcloud config get-value project)
REGION="us-central1"
REPO_NAME="fintech-agent-repo"
IMAGE_NAME="buy-or-wait-engine"
TAG=$(git rev-parse --short HEAD || echo "latest")

IMAGE_URI="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO_NAME}/${IMAGE_NAME}:${TAG}"

echo "Building Docker image: ${IMAGE_NAME}:${TAG}..."
# (Assumes a standard Dockerfile is in the root directory)
docker build -t ${IMAGE_NAME}:${TAG} .

echo "Tagging image for Artifact Registry..."
docker tag ${IMAGE_NAME}:${TAG} ${IMAGE_URI}
docker tag ${IMAGE_NAME}:${TAG} "${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO_NAME}/${IMAGE_NAME}:latest"

echo "Pushing image to GCP Artifact Registry..."
docker push ${IMAGE_URI}
docker push "${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO_NAME}/${IMAGE_NAME}:latest"

echo "Build and push successful: ${IMAGE_URI}"