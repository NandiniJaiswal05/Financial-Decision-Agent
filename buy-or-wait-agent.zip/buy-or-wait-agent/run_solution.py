import os
import sys
import csv
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from src.ledger.fx_converter import FXConverter
from src.ledger.state_builder import LedgerStateBuilder
from src.engine.cash_flow import CashFlowSimulator
from src.engine.plan_optimizer import PlanOptimizer, PaymentOption, CandidatePlan
from src.perception.client import VertexPerceptionClient
from src.utils.schema_validation import OutputPrediction
from src.utils.token_tracker import TokenTracker


# =====================================================================
# 1. HELPER PARSERS FOR SUPPORTING DATASETS
# =====================================================================

def load_payment_options(filepath: str) -> Dict[str, List[PaymentOption]]:
    """
    Parses dataset/request_payment_options.csv cleanly handling missing/NaN values.
    """
    options_by_request: Dict[str, List[PaymentOption]] = {}
    if not os.path.exists(filepath):
        return options_by_request

    df = pd.read_csv(filepath)
    df.columns = [str(c).strip() for c in df.columns]

    for _, row in df.iterrows():
        req_id = str(row['request_id']).strip()
        opt_id = str(row['payment_option_id']).strip()
        opt_type = str(row.get('payment_method', '')).strip().lower()
        start_date_str = str(row.get('first_payment_date', '')).strip()
        
        # Robust NaN Handling for numerical fields
        num_payments = int(row['number_of_payments']) if pd.notna(row.get('number_of_payments')) else 1
        days_between = int(row['payment_frequency_days']) if pd.notna(row.get('payment_frequency_days')) else 0
        fee = float(row.get('financing_fee', 0.0)) if pd.notna(row.get('financing_fee')) else 0.0
        total_payable = float(row['total_payable_amount']) if pd.notna(row.get('total_payable_amount')) else 0.0

        # Calculate chronological payment schedule
        schedule: List[Tuple[str, float]] = []
        if start_date_str and start_date_str.lower() != 'nan':
            try:
                base_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
                per_payment_amt = round(total_payable / max(1, num_payments), 2)

                for i in range(num_payments):
                    pay_date = base_date + timedelta(days=i * days_between)
                    amt = per_payment_amt if i < num_payments - 1 else round(total_payable - (per_payment_amt * (num_payments - 1)), 2)
                    schedule.append((pay_date.strftime("%Y-%m-%d"), amt))
            except ValueError:
                pass

        option = PaymentOption(
            payment_option_id=opt_id,
            request_id=req_id,
            option_type=opt_type,
            start_date=start_date_str,
            num_payments=num_payments,
            days_between_payments=days_between,
            explicit_financing_fee=fee,
            total_payable_amount=total_payable,
            payment_schedule=schedule
        )

        if req_id not in options_by_request:
            options_by_request[req_id] = []
        options_by_request[req_id].append(option)

    return options_by_request


def load_messages_and_images(messages_path: str, images_path: str) -> Tuple[List[dict], List[dict]]:
    """Loads supporting message and image metadata tables."""
    messages = []
    if os.path.exists(messages_path):
        df_msg = pd.read_csv(messages_path)
        df_msg.columns = [str(c).strip() for c in df_msg.columns]
        messages = df_msg.to_dict(orient='records')

    images = []
    if os.path.exists(images_path):
        df_img = pd.read_csv(images_path)
        df_img.columns = [str(c).strip() for c in df_img.columns]
        images = df_img.to_dict(orient='records')

    return messages, images


def build_explanation(
    plan: CandidatePlan,
    amount_safe_to_pay: float,
    earliest_date_for_full_payment: Optional[str],
    requested_amount: float,
    min_balance: float,
    home_currency: str
) -> str:
    """Generates explanation detailing the financial facts behind the recommendation."""
    if plan.affordability_status == "affordable_now":
        return (
            f"The full requested amount of {requested_amount:.2f} {home_currency} is safe to pay today "
            f"while maintaining your required minimum balance of {min_balance:.2f} {home_currency} over the 90-day forecast."
        )
    elif plan.affordability_status == "affordable_with_plan":
        changes_note = (
            f" with spending changes ({plan.spending_changes_str})" 
            if plan.spending_changes_str != "none" else ""
        )
        return (
            f"Recommended {plan.recommended_payment_method} method{changes_note}. Today's maximum safe payment capacity is "
            f"{amount_safe_to_pay:.2f} {home_currency}. Full payment becomes safe on {earliest_date_for_full_payment}."
        )
    elif plan.affordability_status == "affordable_later":
        return (
            f"Full payment of {requested_amount:.2f} {home_currency} is not safe today without breaching your minimum balance "
            f"of {min_balance:.2f} {home_currency}. The earliest safe date for full payment is {earliest_date_for_full_payment}."
        )
    else:
        return (
            f"The request of {requested_amount:.2f} {home_currency} cannot be safely completed within the 90-day forecast window "
            f"while maintaining your required minimum balance of {min_balance:.2f} {home_currency}."
        )


# =====================================================================
# 2. MASTER PIPELINE EXECUTION ENGINE
# =====================================================================

def main():
    print("=================================================================")
    print("  BUY OR WAIT? FINTECH AGENT - MASTER EXECUTION PIPELINE")
    print("=================================================================\n")

    base_dir = "."
    dataset_dir = os.path.join(base_dir, "dataset")
    requests_path = os.path.join(dataset_dir, "requests.csv")
    profiles_path = os.path.join(dataset_dir, "financial_profiles.csv")
    events_path = os.path.join(dataset_dir, "financial_events.csv")
    rates_path = os.path.join(dataset_dir, "exchange_rates.csv")
    options_path = os.path.join(dataset_dir, "request_payment_options.csv")
    messages_path = os.path.join(dataset_dir, "messages.csv")
    images_path = os.path.join(dataset_dir, "images.csv")
    media_dir = os.path.join(dataset_dir, "media", "images")
    output_path = os.path.join(base_dir, "output.csv")

    if not os.path.exists(requests_path):
        print(f"Error: Required evaluation file not found at '{requests_path}'")
        sys.exit(1)

    # Step 1: Initialize Ledger & FX Converter
    print("[1/5] Loading exchange rates and building financial state ledgers...")
    fx_converter = FXConverter(rates_path)
    state_builder = LedgerStateBuilder(profiles_path, events_path, fx_converter)

    # Step 2: Initialize Perception Engine & Targeted Extraction
    print("[2/5] Running targeted multimodal perception (OCR & NLP)...")
    perception_client = VertexPerceptionClient()
    messages, images = load_messages_and_images(messages_path, images_path)
    perception_overrides = []

    # Process linked images
    for img in images:
        related_event_id = str(img.get('related_event_id', '')).strip()
        image_id = str(img.get('image_id', '')).strip()
        user_id = str(img.get('user_id', '')).strip()

        if image_id and image_id.lower() != 'nan':
            img_file = os.path.join(media_dir, f"{image_id}.png")
            if os.path.exists(img_file):
                result = perception_client.extract_from_image(img_file, related_event_id=related_event_id)
                for override in result.overrides:
                    override_dict = override.model_dump()
                    override_dict['user_id'] = user_id
                    perception_overrides.append(override_dict)

    # Process linked messages
    for msg in messages:
        msg_text = str(msg.get('message_text', '')).strip()
        related_event_id = str(msg.get('related_event_id', '')).strip()
        user_id = str(msg.get('user_id', '')).strip()

        if msg_text and msg_text.lower() != 'nan':
            result = perception_client.extract_from_message(msg_text, related_event_id=related_event_id)
            for override in result.overrides:
                override_dict = override.model_dump()
                override_dict['user_id'] = user_id
                perception_overrides.append(override_dict)

    if perception_overrides:
        state_builder.apply_perception_overrides(perception_overrides)

    # Step 3: Load Payment Options and Requests
    print("[3/5] Ingesting request evaluation items and payment options...")
    options_by_request = load_payment_options(options_path)
    requests_df = pd.read_csv(requests_path)
    requests_df.columns = [str(c).strip() for c in requests_df.columns]
    total_requests = len(requests_df)

    # Step 4: Evaluate Requests & Run Solver
    print(f"[4/5] Executing 90-day cash flow simulation across {total_requests} requests...")
    output_rows = []

    for idx, row in requests_df.iterrows():
        req_id = str(row['request_id']).strip()
        user_id = str(row['user_id']).strip()
        req_date = str(row['request_date']).strip()
        req_amount = float(row['requested_amount'])
        desired_completion = str(row['desired_completion_date']).strip()
        
        allows_partial_raw = str(row.get('allows_partial_payment', 'False')).strip().lower()
        allows_partial = allows_partial_raw in ('true', '1', 'yes', 't')

        profile = state_builder.get_user_profile(user_id)
        events = state_builder.get_active_events(user_id)
        payment_opts = options_by_request.get(req_id, [])

        # 4a. Run cash flow capacity solver
        simulator = CashFlowSimulator(profile, events)
        amount_safe, earliest_date_full = simulator.compute_capacity(req_date, req_amount)

        # 4b. Run plan optimizer & ranking matrix
        optimizer = PlanOptimizer(profile, events, simulator, payment_opts)
        best_plan = optimizer.find_best_plan(
            request_date_str=req_date,
            requested_amount=req_amount,
            desired_completion_date_str=desired_completion,
            allows_partial_payment=allows_partial,
            amount_safe_to_pay=amount_safe,
            earliest_date_for_full_payment=earliest_date_full
        )

        earliest_out = earliest_date_full
        if best_plan.affordability_status == "affordable_now":
            earliest_out = req_date

        # 4c. Synthesize explanation
        explanation = build_explanation(
            plan=best_plan,
            amount_safe_to_pay=amount_safe,
            earliest_date_for_full_payment=earliest_out,
            requested_amount=req_amount,
            min_balance=profile.minimum_balance_to_keep,
            home_currency=profile.home_currency
        )

        # 4d. Validate prediction object against invariants
        pred = OutputPrediction(
            request_id=req_id,
            amount_safe_to_pay=amount_safe,
            affordability_status=best_plan.affordability_status,
            recommended_payment_method=best_plan.recommended_payment_method,
            payment_plan=best_plan.payment_plan_str,
            earliest_date_for_full_payment=earliest_out,
            spending_changes_needed=best_plan.spending_changes_str,
            decision_explanation=explanation
        )
        pred.set_requested_amount(req_amount)
        pred.enforce_invariants()

        output_rows.append(pred.to_csv_dict())

    # Step 5: Save Predictions & Write Usage Report
    print(f"[5/5] Writing output predictions to '{output_path}' and compiling token usage report...")
    fieldnames = [
        "request_id",
        "amount_safe_to_pay",
        "affordability_status",
        "recommended_payment_method",
        "payment_plan",
        "earliest_date_for_full_payment",
        "spending_changes_needed",
        "decision_explanation"
    ]

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(output_rows)

    token_tracker = TokenTracker()
    token_tracker.generate_report(total_requests=total_requests, output_filepath="evaluation/usage_report.md")

    print("\n=================================================================")
    print("  EXECUTION COMPLETE: All predictions generated successfully!")
    print(f"  - Output File: {output_path}")
    print("  - Token Report: evaluation/usage_report.md")
    print("=================================================================")


if __name__ == "__main__":
    main()