# Token Usage and Cost Analysis Report

## Summary of Execution Run
- **Total Benchmark Requests Evaluated:** 25
- **Total LLM/VLM API Calls:** 231
- **Failed API Calls (Safeguards/Timeouts):** 0
- **Total Input Tokens:** 139,722
- **Total Output Tokens:** 27,690
- **Average Tokens Per Request:** 6696.48

## Model Breakdown

| Model Name | Calls | Input Tokens | Output Tokens | Est. Input Cost ($) | Est. Output Cost ($) | Total Cost ($) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `gemini-2.5-flash` | 231 | 139,722 | 27,690 | $0.0105 | $0.0083 | **$0.0188** |

## Financial Summary
- **Estimated Total Run Cost:** `$0.0188`
- **Estimated Cost Per Request:** `$0.000751`