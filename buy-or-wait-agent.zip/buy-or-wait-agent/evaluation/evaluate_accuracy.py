import os
import pandas as pd
from typing import Dict, Any


def evaluate_sample_predictions(
    predictions_path: str = "output.csv",
    sample_truth_path: str = "dataset/sample_requests.csv"
):
    print("=================================================================")
    print("  ACCURACY & DECISION QUALITY BENCHMARK ENGINE")
    print("=================================================================\n")

    if not os.path.exists(predictions_path):
        print(f"Error: Predictions file not found at '{predictions_path}'. Run run_solution.py first.")
        return

    if not os.path.exists(sample_truth_path):
        print(f"Error: Sample ground-truth file not found at '{sample_truth_path}'.")
        return

    # Load data
    pred_df = pd.read_csv(predictions_path)
    truth_df = pd.read_csv(sample_truth_path)

    pred_df.columns = [str(c).strip() for c in pred_df.columns]
    truth_df.columns = [str(c).strip() for c in truth_df.columns]

    # Index by request_id
    preds: Dict[str, dict] = {str(r['request_id']).strip(): r for _, r in pred_df.iterrows()}
    
    total_samples = 0
    matches = {
        "amount_safe_to_pay": 0,
        "affordability_status": 0,
        "recommended_payment_method": 0,
        "payment_plan": 0,
        "earliest_date_for_full_payment": 0,
        "spending_changes_needed": 0,
        "exact_row_matches": 0
    }
    
    abs_errors = []

    for _, truth_row in truth_df.iterrows():
        req_id = str(truth_row['request_id']).strip()
        if req_id not in preds:
            continue

        total_samples += 1
        p = preds[req_id]

        # 1. Numerical evaluation: amount_safe_to_pay
        p_safe = float(p['amount_safe_to_pay'])
        t_safe = float(truth_row['amount_safe_to_pay'])
        mae = abs(p_safe - t_safe)
        abs_errors.append(mae)

        if mae <= 0.01:
            matches["amount_safe_to_pay"] += 1

        # 2. Categorical evaluations
        if str(p['affordability_status']).strip() == str(truth_row['affordability_status']).strip():
            matches["affordability_status"] += 1

        if str(p['recommended_payment_method']).strip() == str(truth_row['recommended_payment_method']).strip():
            matches["recommended_payment_method"] += 1

        if str(p['payment_plan']).strip() == str(truth_row['payment_plan']).strip():
            matches["payment_plan"] += 1

        p_earliest = str(p['earliest_date_for_full_payment']).strip() if pd.notna(p['earliest_date_for_full_payment']) else ""
        t_earliest = str(truth_row['earliest_date_for_full_payment']).strip() if pd.notna(truth_row['earliest_date_for_full_payment']) else ""
        if p_earliest == t_earliest:
            matches["earliest_date_for_full_payment"] += 1

        if str(p['spending_changes_needed']).strip() == str(truth_row['spending_changes_needed']).strip():
            matches["spending_changes_needed"] += 1

        # Check full row exact match
        if (
            mae <= 0.01 and
            str(p['affordability_status']).strip() == str(truth_row['affordability_status']).strip() and
            str(p['recommended_payment_method']).strip() == str(truth_row['recommended_payment_method']).strip() and
            str(p['payment_plan']).strip() == str(truth_row['payment_plan']).strip() and
            p_earliest == t_earliest and
            str(p['spending_changes_needed']).strip() == str(truth_row['spending_changes_needed']).strip()
        ):
            matches["exact_row_matches"] += 1

    if total_samples == 0:
        print("No matching request_ids found between predictions and sample ground truth.")
        return

    # Metrics Summary
    avg_mae = sum(abs_errors) / total_samples
    print(f"Evaluated {total_samples} ground-truth sample requests:\n")
    print(f"| Evaluation Metric | Accuracy / Score |")
    print(f"| :--- | :--- |")
    print(f"| **amount_safe_to_pay Accuracy (Exact)** | {(matches['amount_safe_to_pay'] / total_samples) * 100:.1f}% |")
    print(f"| **amount_safe_to_pay MAE** | {avg_mae:.2f} |")
    print(f"| **affordability_status Accuracy** | {(matches['affordability_status'] / total_samples) * 100:.1f}% |")
    print(f"| **recommended_payment_method Accuracy** | {(matches['recommended_payment_method'] / total_samples) * 100:.1f}% |")
    print(f"| **payment_plan Format & Schedule Match** | {(matches['payment_plan'] / total_samples) * 100:.1f}% |")
    print(f"| **earliest_date_for_full_payment Match** | {(matches['earliest_date_for_full_payment'] / total_samples) * 100:.1f}% |")
    print(f"| **spending_changes_needed Match** | {(matches['spending_changes_needed'] / total_samples) * 100:.1f}% |")
    print(f"| **PERFECT FULL-ROW MATCH RATE** | **{(matches['exact_row_matches'] / total_samples) * 100:.1f}%** |")
    print("\n=================================================================")


if __name__ == "__main__":
    evaluate_sample_predictions()