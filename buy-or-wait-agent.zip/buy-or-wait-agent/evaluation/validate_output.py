import os
import sys
import re
import pandas as pd
from typing import List, Tuple


class OutputValidator:
    ALLOWED_STATUSES = {
        "affordable_now",
        "affordable_with_plan",
        "affordable_later",
        "not_affordable"
    }

    ALLOWED_METHODS = {
        "full_payment",
        "partial_payment",
        "installments",
        "wait",
        "not_recommended"
    }

    REQUIRED_COLUMNS = [
        "request_id",
        "amount_safe_to_pay",
        "affordability_status",
        "recommended_payment_method",
        "payment_plan",
        "earliest_date_for_full_payment",
        "spending_changes_needed",
        "decision_explanation"
    ]

    def __init__(self, output_path: str = "output.csv", requests_path: str = "dataset/requests.csv"):
        self.output_path = output_path
        self.requests_path = requests_path
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def validate(self) -> bool:
        print(f"--- Running Validation Audit on '{self.output_path}' ---")

        if not os.path.exists(self.output_path):
            self.errors.append(f"File not found: {self.output_path}")
            return self._print_results()

        if not os.path.exists(self.requests_path):
            self.warnings.append(f"Requests benchmark file missing at '{self.requests_path}'. Skipping relational cross-check.")
            requests_df = None
        else:
            requests_df = pd.read_csv(self.requests_path)

        try:
            output_df = pd.read_csv(self.output_path, keep_default_na=False)
        except Exception as e:
            self.errors.append(f"Failed to parse CSV: {str(e)}")
            return self._print_results()

        # 1. Header and Column Count Validation
        if list(output_df.columns) != self.REQUIRED_COLUMNS:
            self.errors.append(f"Column headers do not match required spec.\n  Expected: {self.REQUIRED_COLUMNS}\n  Found:    {list(output_df.columns)}")
            return self._print_results()

        # 2. Row Count Alignment
        if requests_df is not None and len(output_df) != len(requests_df):
            self.errors.append(f"Row count mismatch! requests.csv has {len(requests_df)} rows, output.csv has {len(output_df)} rows.")

        # Re-index requests for row-level verification
        req_map = {}
        if requests_df is not None:
            for _, r_row in requests_df.iterrows():
                req_map[str(r_row['request_id']).strip()] = r_row

        # 3. Row-by-Row Invariant Checks
        plan_regex = re.compile(r"^(\d{4}-\d{2}-\d{2}:\d+(\.\d+)?)(\|\d{4}-\d{2}-\d{2}:\d+(\.\d+)?)*$")

        for idx, row in output_df.iterrows():
            row_num = idx + 2  # Accounting for 1-based index + header row
            req_id = str(row['request_id']).strip()
            
            # Numeric conversion check
            try:
                safe_pay = float(row['amount_safe_to_pay'])
            except ValueError:
                self.errors.append(f"Row {row_num} ({req_id}): amount_safe_to_pay '{row['amount_safe_to_pay']}' is not a valid float.")
                continue

            status = str(row['affordability_status']).strip()
            method = str(row['recommended_payment_method']).strip()
            plan = str(row['payment_plan']).strip()
            earliest_date = str(row['earliest_date_for_full_payment']).strip()
            spending = str(row['spending_changes_needed']).strip()
            explanation = str(row['decision_explanation']).strip()

            # Check requested amount ceiling
            if req_id in req_map:
                req_amt = float(req_map[req_id]['requested_amount'])
                req_date = str(req_map[req_id]['request_date']).strip()
                allows_partial = bool(req_map[req_id]['allows_partial_payment'])

                if safe_pay < 0.0 or safe_pay > req_amt + 0.01:
                    self.errors.append(f"Row {row_num} ({req_id}): amount_safe_to_pay ({safe_pay}) violates range [0, {req_amt}].")

                # Invariant: affordable_now requires earliest_date_for_full_payment == request_date
                if status == "affordable_now" and earliest_date != req_date:
                    self.errors.append(f"Row {row_num} ({req_id}): Status is 'affordable_now' but earliest_date_for_full_payment '{earliest_date}' != request_date '{req_date}'.")

                # Invariant: partial_payment rules
                if method == "partial_payment":
                    if status != "affordable_with_plan":
                        self.errors.append(f"Row {row_num} ({req_id}): Method 'partial_payment' requires status 'affordable_with_plan', got '{status}'.")
                    if not allows_partial:
                        self.errors.append(f"Row {row_num} ({req_id}): Method 'partial_payment' recommended but request disallows partial payments.")

            # Allowed value checks
            if status not in self.ALLOWED_STATUSES:
                self.errors.append(f"Row {row_num} ({req_id}): Invalid affordability_status '{status}'.")

            if method not in self.ALLOWED_METHODS:
                self.errors.append(f"Row {row_num} ({req_id}): Invalid recommended_payment_method '{method}'.")

            # Payment plan syntax check
            if plan != "none" and not plan_regex.match(plan):
                self.errors.append(f"Row {row_num} ({req_id}): Invalid payment_plan format '{plan}'.")

            # Spending changes format check
            if spending != "none":
                parts = spending.split("|")
                if len(parts) > 3:
                    self.errors.append(f"Row {row_num} ({req_id}): spending_changes_needed exceeds 3 items ({len(parts)} found).")
                
                seen_events = set()
                for part in parts:
                    sub_parts = part.split(":")
                    if sub_parts[0] not in ("stop", "reduce_to"):
                        self.errors.append(f"Row {row_num} ({req_id}): Invalid change action '{sub_parts[0]}' in spending_changes_needed.")
                    if len(sub_parts) > 1:
                        event_id = sub_parts[1]
                        if event_id in seen_events:
                            self.errors.append(f"Row {row_num} ({req_id}): Duplicate/conflicting event '{event_id}' in spending_changes_needed.")
                        seen_events.add(event_id)

            # Explanation length check
            if not explanation:
                self.errors.append(f"Row {row_num} ({req_id}): decision_explanation is blank.")

        return self._print_results()

    def _print_results(self) -> bool:
        if self.warnings:
            print("\n[WARNINGS]")
            for w in self.warnings:
                print(f"  - {w}")

        if self.errors:
            print(f"\n[FAIL] Validation Failed with {len(self.errors)} Error(s):")
            for e in self.errors[:25]:  # Print first 25 errors to prevent terminal flooding
                print(f"  - {e}")
            if len(self.errors) > 25:
                print(f"  ... and {len(self.errors) - 25} more error(s).")
            return False

        print("\n[SUCCESS] Output file passes all schema, invariant, and relational checks!")
        return True


if __name__ == "__main__":
    out_file = sys.argv[1] if len(sys.argv) > 1 else "output.csv"
    req_file = sys.argv[2] if len(sys.argv) > 2 else "dataset/requests.csv"
    validator = OutputValidator(out_file, req_file)
    success = validator.validate()
    sys.exit(0 if success else 1)