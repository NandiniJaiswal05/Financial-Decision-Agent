# app.py
import streamlit as st
import pandas as pd
import requests

st.set_page_config(page_title="Buy or Wait? Financial Advisor", page_icon="💳", layout="wide")

st.title("💳 Buy or Wait? — AI Financial Affordability Agent")
st.markdown("Test purchase affordability in real-time with 90-day cash flow simulations and multimodal perception safeguards.")

# Sidebar Controls for User Input
st.sidebar.header("User Parameters")
user_id = st.sidebar.selectbox("Select User Profile", ["user_01", "user_02", "user_03"])
current_balance = st.sidebar.number_input("Current Balance ($)", value=2500.0)
min_balance = st.sidebar.number_input("Minimum Balance Threshold ($)", value=300.0)

st.divider()

# Main Purchase Form
col1, col2 = st.columns(2)
with col1:
    item_name = st.text_input("Item / Purchase Description", value="MacBook Pro M3")
    requested_amount = st.number_input("Purchase Amount ($)", value=1499.0, min_value=1.0)
with col2:
    request_date = st.date_input("Purchase Request Date")
    desired_completion = st.date_input("Desired Completion Date")
    allows_partial = st.checkbox("Allow Partial Payments", value=True)

if st.button("Evaluate Affordability 🚀", type="primary"):
    with st.spinner("Analyzing 90-day cash flow trajectory & checking recurring expenses..."):
        # Simulate local engine evaluation or call your Cloud Run API URL
        # api_url = "https://your-cloud-run-url.a.run.app/evaluate"
        
        # Mocking real-time evaluation logic for instant UI feedback
        safe_to_pay = max(0.0, current_balance - min_balance)
        is_affordable = safe_to_pay >= requested_amount
        
        st.subheader("📊 Affordability Decision Result")
        
        res_col1, res_col2, res_col3 = st.columns(3)
        with res_col1:
            st.metric("Safe Amount to Pay Today", f"${min(requested_amount, safe_to_pay):.2f}")
        with res_col2:
            status_label = "✅ Affordable Now" if is_affordable else "⚠️ Affordable With Plan"
            st.metric("Affordability Status", status_label)
        with res_col3:
            st.metric("Recommended Method", "Full Payment" if is_affordable else "Installments")

        # Visualizing 90-day simulated balance trajectory
        st.divider()
        st.subheader("📈 Simulated 90-Day Balance Trajectory ($)")
        
        days = pd.date_range(start=str(request_date), periods=90, freq='D')
        # Generate sample trajectory curve showing salary inflows and expense drops
        balance_curve = [current_balance - (i * 15) + (2000 if i in [3, 33, 63] else 0) for i in range(90)]
        chart_data = pd.DataFrame({"Date": days, "Projected Balance": balance_curve, "Minimum Threshold": [min_balance]*90})
        chart_data.set_index("Date", inplace=True)
        
        st.line_chart(chart_data)
        
        if is_affordable:
            st.success(f"Success! You can safely purchase **{item_name}** today without breaching your minimum balance threshold.")
        else:
            st.warning(f"Caution: Full payment today leaves you below your safety buffer. Recommended: Wait until salary deposit or choose a 3-month installment plan.")